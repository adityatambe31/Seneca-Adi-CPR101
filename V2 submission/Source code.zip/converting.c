//CONVERTING MODULE SOURCE


#define _CRT_SECURE_NO_WARNINGS
#define BUFFER_SIZE 80
#include "converting.h"

// converting function started with void argument defined...
void converting(void) 
{

/* Version 2 */

// used double datatype replacing the integer datatype for smoother experience...

            printf("* Start of Converting Strings to double Demo *\n");

        // declearing an character array with BUFFER_SIZE named doubleString..         
        char doubleString[BUFFER_SIZE];

        // declearing the double datatype variable, named doubleNumber....
        double doubleNumber;


    //do-while loop initalized..
    do 
    {
            // printing the statement with the print function..
            printf("Type the double numeric string (q - to quit):\n");
            
            // taking user input and storing it in the doubleString into a string....
            fgets(doubleString, BUFFER_SIZE, stdin);

        // cutting of the last character of doubleString and replacing it with the null character...
        doubleString[strlen(doubleString) - 1] - '\0';

            // if condition initialized...
            if ((strcmp(doubleString, "q") != 0))
            {
                /* converting string of characters and then representing it as an actual doubles
                and then storing it into doubleNumber*/
                doubleNumber = atof(doubleString);

                // printed the conversion of numbers  with the help o printf funtion...
                printf("Converted number is %f\n", doubleNumber);
            }

    } while (strcmp(doubleString, "q") != 0);
    
            // printing a statement for ending of our program with printf function....
            printf("* End of Converting Strings to double Demo *\n\n");

}
