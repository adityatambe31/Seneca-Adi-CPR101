// MANIPULATING MODULE HEADER 
#ifndef _MANIPULATING_H_ // checking if identifier "_MANIPULATING_H_" is not defined

#define _MANIPULATING_H_ // defining identifier "_MANIPULATING_H_" is not defined

#include <stdio.h> // include the standard library for input output operations.
#include <string.h> // including the string library

void manipulating(void); // declearation of the function for "fundamentals" function with zero parameters.

#endif 