// MANIPULATING SOURCE
#define _CRT_SECURE_NO_WARNINGS
#define BUFFER_SIZE 80
#include "manipulating.h"



// starting "manipulating" function with void as an argument passed to the function..
void manipulating(void) 
{/* Version 2 */
    
    
            // printing the starting line of our program..
            printf("* Start of Comparing Strings Demo *\n");

        //declaring new char arrays compare1, compare2 replacing older variables string1 and string2 and assinging same BUFFER_SIZE 
        char compare1[BUFFER_SIZE];
        char compare2[BUFFER_SIZE];

        // declearing new integer datatype variable named result.
        int result;
    
    // do-while loop initialised...
    do
    {
            // printing the statement using the print function
            printf("Type the 1st string to compare (q - to quit):\n");

            // taking the user input and storing it to new variable created compare1
            fgets(compare1, BUFFER_SIZE, stdin);

        // cutting of the last character of compare1 and replacing it with the null character...
        compare1[strlen(compare1) - 1] = '\0';
        

        //if condition intialized...
        if (strcmp(compare1, "q") != 0)
        {
            
            // printing the statement using the print function...
            printf("Type the 2nd string to compare:\n");

            // taking the user input and storing it to new variable created compare2.....
            fgets(compare2, BUFFER_SIZE, stdin);


            // cutting of the last character of compare2 and replacing it with the null character...
            compare2[strlen(compare2) - 1] = '\0';

            //storing the string comparison in the result variable defined already...
            result = strcmp(compare1, compare2);

            //new if condition added regarding new variable result and intialized..
            
            if (result < 0)
                    // print the statement if result is less than 0...
                    printf("\'%s\' string is less than \'%s\'\n", compare1, compare2);
            
            else if (result == 0)
                
                    // print the statement if result equals to 0
                    printf("\'%s\' string is equal to \'%s\'\n", compare1, compare2);
            else

                // print the statement if result equals to 0
                printf("\'%s\' string is greater than \'%s\'\n", compare1, compare2);
        }
    } while (strcmp(compare1, "q") != 0);

            // printing the end line for our program and program ends...
            printf("* End of Comparing Strings Demo *\n\n");
}
