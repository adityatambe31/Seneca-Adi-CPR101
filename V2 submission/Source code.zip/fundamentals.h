// FUNDAMENTALS MODULE HEADER 
#ifndef _FUNDAMENTALS_H_ // checking if the identifier "_FUNDAMENTALS_H_" is present or not.

#define _FUNDAMENTALS_H_ // defining the identifier"_FUNDAMENTALS_H_"

#include <stdio.h> // include the standard library for input output operations.
#include <stdlib.h> // including for standard library functions like memory allocation.
#include <string.h> // including the string library

void fundamentals(void); // declearation of the function for "fundamentals" function with zero parameters.
#endif 