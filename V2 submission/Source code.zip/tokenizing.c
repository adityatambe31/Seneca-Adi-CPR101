// TOKENIZING MODULE SOURCE
#define _CRT_SECURE_NO_WARNINGS
#define BUFFER_SIZE 300
#include "tokenizing.h"


// starting "tokenizing" function with void as an argument passed to the function..
void tokenizing(void) 
{
    //replaced the old variables and introduced new variables for better functionality...

            // printing the start of our program...
            printf("* Start of Tokenizing Phrases Demo **\n");


        // declearing an array named phrases with the BUFFER_SIZE, a pointer with the named nextPhrase assigning NULL value to it...
        char phrases[BUFFER_SIZE];
        char* nextPhrase = NULL;

        // declearing phrasesCounter interger datatype variable..
        int phrasesCounter;
    
    //do-while initialized...
    do 
    {
                //print the below statement with the help of print function...
                printf("Type a few phrases separated by comma(q - to quit):\n");
                
                //taking the user input and storing it in phrases variable already defined..
                fgets(phrases, BUFFER_SIZE, stdin);
                

            // cutting of the last character of phrases and replacing it with the null character...
            phrases[strlen(phrases) - 1] = '\0';
            
        
        //if condition intialized...
        if ((strcmp(phrases, "q") != 0))
        {

            // reading the string as series of tokens and storing into the nextWord variable..
            nextPhrase = strtok(phrases, ",");

            // assinging one value to variable phraseCounter..
            phrasesCounter = 1;
            
            //nested while in do-while loop
            while (nextPhrase) 
            {
                // printing the phraseCounter and nextPhrase with the help of print function...
                printf("Phrase #%d is \'%s\'\n", phrasesCounter++, nextPhrase);

                // reading the string as series of tokens and storing into the nextWord variable..
                nextPhrase = strtok(NULL, ",");
            }
        }

    } while (strcmp(phrases, "q") != 0);

                // last statement of our program and then it ends....
                printf("* End of Tokenizing Phrases Demo *\n\n");
}