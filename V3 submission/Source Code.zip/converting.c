// CONVERTING MODULE SOURCE


#define _CRT_SECURE_NO_WARNINGS
#define BUFFER_SIZE 80
#include "converting.h"

// converting function started with void argument defined...
void converting(void) {
    /* Version 1 */

        // printing statment with the printf function....
            printf("*** Start of Converting Strings to int Demo ***\n");
        
        // declearing the character variable, named intString with BUFFER_SIZE pre-defined...
        char intString[BUFFER_SIZE];

        // declearing the integer datatype variable, named intNumber....
        int  intNumber;

        // do while loop initialized...
        do
        {
            // printing the above statement with printf function...
            printf("Type an int numeric string (q - to quit):\n");

            // taking the above user input and storing it in intString...
            fgets(intString, BUFFER_SIZE, stdin);
            
            // cutting of the last character of intString and replacing it with the null character...
            intString[strlen(intString) - 1] = '\0';
        
            // if condition intialized..
            if (strcmp(intString, "q") != 0) 
            {
                /* converting string of characters and then representing it as an actual integers
                and then storing it into intNumber*/
                intNumber = atoi(intString);
                    
                    // printed the conversion of numbers  with the help o printf funtion...
                    printf("Converted number is %d\n", intNumber);
            }
        } while (strcmp(intString, "q") != 0);
            
            // printing a statement for ending of our program with printf function....
            printf("*** End of Converting Strings to int Demo ***\n\n");

    

/* Version 2 */

// used double datatype replacing the integer datatype for smoother experience...

            printf("* Start of Converting Strings to double Demo *\n");

        // declearing an character array with BUFFER_SIZE named doubleString..         
        char doubleString[BUFFER_SIZE];

        // declearing the double datatype variable, named doubleNumber....
        double doubleNumber;


    //do-while loop initalized..
    do 
    {
            // printing the statement with the print function..
            printf("Type the double numeric string (q - to quit):\n");
            
            // taking user input and storing it in the doubleString into a string....
            fgets(doubleString, BUFFER_SIZE, stdin);

        // cutting of the last character of doubleString and replacing it with the null character...
        doubleString[strlen(doubleString) - 1] - '\0';

            // if condition initialized...
            if ((strcmp(doubleString, "q") != 0))
            {
                /* converting string of characters and then representing it as an actual doubles
                and then storing it into doubleNumber*/
                doubleNumber = atof(doubleString);

                // printed the conversion of numbers  with the help o printf funtion...
                printf("Converted number is %f\n", doubleNumber);
            }

    } while (strcmp(doubleString, "q") != 0);
    
            // printing a statement for ending of our program with printf function....
            printf("* End of Converting Strings to double Demo *\n\n");


/* Version 3 */
/* Version 3 */
    printf("* Start of Converting Strings to long Demo *\n");


        char longString[BUFFER_SIZE];
        long longNumber;
    
    
    do {

            // printing statment with the printf function....
            printf("Type the long numeric string (q - to quit):\n");
            
             // taking user input and storing it in the longString into a string....
            fgets(longString, BUFFER_SIZE, stdin);

    
    // cutting of the last character of doubleString and replacing it with the null character...
        longString[strlen(longString) - 1] = '\0';


            // if condition initialized...
            if ((strcmp(longString, "q") != 0)) 
            {
                /* converting string of characters and then representing it as an actual longs
                and then storing it into longNumber*/
                longNumber = atol(longString);
                
                // printing the conversion of numbers  with the help o printf funtion...
                printf("Converted number is %ld\n", longNumber);
            }

    } while (strcmp(longString, "q") != 0);
            
            // printing a statement for ending of our program with printf function....
            printf("* End of Converting Strings to long Demo***\n\n");

}

