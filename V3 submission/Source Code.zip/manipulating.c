// MANIPULATING SOURCE
#define _CRT_SECURE_NO_WARNINGS
#define BUFFER_SIZE 80
#include "manipulating.h"



// starting "manipulating" function with void as an argument passed to the function..
void manipulating(void) 
{
    /* Version 1 */

            // printing the starting line of our program..
            printf("*** Start of Concatenating Strings Demo ***\n");
        
        // // declearing the character arrays named string1 and string2 with sizes BUFFER_SIZE.
        char string1[BUFFER_SIZE];
        char string2[BUFFER_SIZE];
    
    // do while loop initialized..
    do 
    {
            // printing the statement and asking user to type the first string..
            printf("Type the 1st string (q - to quit):\n");

            // taking the above user input and storing it in string1...
            fgets(string1, BUFFER_SIZE, stdin);
        
        // cutting of the last character of numInput and replacing it with the null character...
        string1[strlen(string1) - 1] = '\0';


            if ((strcmp(string1, "q") != 0)) 
            {
                    //printing the above statement using print function
                    printf("Type the 2nd string:\n");

                    // taking the user input and storing it in string2...
                    fgets(string2, BUFFER_SIZE, stdin);

                
                // cutting of the last character of buffer1 and replacing it with the null character...
                string2[strlen(string2) - 1] = '\0';
                
                // concating string1 and string2
                strcat(string1, string2);

                    printf("Concatenated string is \'%s\'\n", string1);
                    // printing the concatatenated version with the help of print function..
            }

    } while (strcmp(string1, "q") != 0);
    
    
                    // printing the end line for our program and program ends...
                    printf("*** End of Concatenating Strings Demo ***\n\n");




/* Version 2 */
    
    
            // printing the starting line of our program..
            printf("* Start of Comparing Strings Demo *\n");

        //declaring new char arrays compare1, compare2 replacing older variables string1 and string2 and assinging same BUFFER_SIZE 
        char compare1[BUFFER_SIZE];
        char compare2[BUFFER_SIZE];

        // declearing new integer datatype variable named result.
        int result;
    
    // do-while loop initialised...
    do
    {
            // printing the statement using the print function
            printf("Type the 1st string to compare (q - to quit):\n");

            // taking the user input and storing it to new variable created compare1
            fgets(compare1, BUFFER_SIZE, stdin);

        // cutting of the last character of compare1 and replacing it with the null character...
        compare1[strlen(compare1) - 1] = '\0';
        

        //if condition intialized...
        if (strcmp(compare1, "q") != 0)
        {
            
            // printing the statement using the print function...
            printf("Type the 2nd string to compare:\n");

            // taking the user input and storing it to new variable created compare2.....
            fgets(compare2, BUFFER_SIZE, stdin);


            // cutting of the last character of compare2 and replacing it with the null character...
            compare2[strlen(compare2) - 1] = '\0';

            //storing the string comparison in the result variable defined already...
            result = strcmp(compare1, compare2);

            //new if condition added regarding new variable result and intialized..
            
            if (result < 0)
                    // print the statement if result is less than 0...
                    printf("\'%s\' string is less than \'%s\'\n", compare1, compare2);
            
            else if (result == 0)
                
                    // print the statement if result equals to 0
                    printf("\'%s\' string is equal to \'%s\'\n", compare1, compare2);
            else

                // print the statement if result equals to 0
                printf("\'%s\' string is greater than \'%s\'\n", compare1, compare2);
        }
    } while (strcmp(compare1, "q") != 0);

            // printing the end line for our program and program ends...
            printf("* End of Comparing Strings Demo *\n\n");


/* Version 3 */

             // printing the starting line of our program..
            printf("* Start of Searching Strings Demo *\n");
        

        //declaring new char arrays haystack, needle replacing older variables compare1 and campare2 and assinging same BUFFER_SIZE 
        char haystack[BUFFER_SIZE];
        char needle[BUFFER_SIZE];

        // one pointer array naemed ouccurance assigning value NULL to it...
        char* occurrence = NULL;
    

    // do-while loop initialised...
    do 
    {

            // printing the statement using the print function...
            printf("Type the string (q - to quit):\n");

            // taking the user input and storing it to new variable created haystack.....
            fgets(haystack, BUFFER_SIZE, stdin);
        

        // cutting of the last character of heystack and replacing it with the null character...
        haystack[strlen(haystack) - 1] = '\0';
        

            //if condition intialized...
            if (strcmp(haystack, "q") != 0) 
            {

                // printing the statement using the print function and asking and user input ...
                printf("Type the substring:\n");

                // taking the user input and storing it to new variable created needle.....
                fgets(needle, BUFFER_SIZE, stdin);


            // cutting of the last character of compare2 and replacing it with the null character...
            needle[strlen(needle) - 1] = '\0';

            //storing the string comparison in the result variable defined already...
            occurrence = strstr(haystack, needle);


                //nested if-else condition intialized...
                if (occurrence)

                        // print the statement if result is occurance...
                        printf("\'%s\' found at %d position\n", needle,
                        (int)(occurrence - haystack));
                
                else
                        //print the statement by using printf function...
                        printf("Not found\n");
            }
    } while (strcmp(haystack, "q") != 0);
            
            // printing the end line for our program and program ends...
            printf("* End of Searching Strings Demo *\n\n");

}
