// CONVERTING MODULE HEADER 
#ifndef _CONVERTING_H_ // checking if identifier "_CONVERTING_H_" is not defined

#define _CONVERTING_H_ // defining the identifier "_CONVERTING_H_".
#include <stdio.h> // include the standard library for input output operations.
#include <stdlib.h> // including for standard library functions like memory allocation.
#include <string.h> // including the string library

void converting(void); // declearation of the function for "converting" function with zero parameters.
#endif  