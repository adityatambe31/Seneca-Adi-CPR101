#define _CRT_NO_WARNINGS 
#include "fundamentals.h"
#include "manipulating.h"
#include "converting.h"
#include "tokenizing.h"

int main(void)
{


    //declaring the character array of size 10 and named buff.. 
        char buff[10];

    //do while loop initialized...
    do
    {
            //printing the statements and asking the user input for which module user wants to go in...
            printf("1 - Fundamentals\n");
            printf("2 - Manipulation\n"); 
            printf("3 - Converting\n"); 
            printf("4 - Tokenizing\n"); 
            printf("0 - Exit\n"); 
            printf("Which module to run? \n"); 

            //taking the user input for the module the user wants to get in and storing the input of his in buff variable...
            fgets(buff, 10, stdin);

        //switch case initialized...
        switch (buff[0])
        {
            //in case1 we care calling the fundamentals if the user decides to go in this module...
            case '1': fundamentals();
                break;

            //in case2 we care calling the manipulating if the user decides to go in this module...
            case '2': manipulating();
                break;
            
            //in case3 we care calling the converting if the user decides to go in this module...
            case '3': converting();
                break;

            //in case4 we care calling the tokenizing if the user decides to go in this module...
            case '4': tokenizing();
                break;
        }
        
    } while (buff[0] != '0');
    return 0;
}