// TOKENIZING MODULE SOURCE
#define _CRT_SECURE_NO_WARNINGS
#define BUFFER_SIZE 300
#include "tokenizing.h"


// starting "tokenizing" function with void as an argument passed to the function..
void tokenizing(void)
{
    /* Version 1 */
    printf("*** Start of Tokenizing Words Demo ***\n");
    // printing the start of our program...

// declearing the character array named words with BUFFER_SIZE.
    char words[BUFFER_SIZE];

    char* nextWord = NULL;
    // declearing character pointer named nextWord and assigning its value to be NULL..
    int wordsCounter;
    // declearing interger data type variable name wordsCounter.


// do-while loop intialized...
    do
    {
        printf("Type a few words separated by space (q - to quit):\n");
        // printing the statement with the print function...
        fgets(words, BUFFER_SIZE, stdin);
        // take the user input and storing it in words

        words[strlen(words) - 1] = '\0';
        // cutting of the last character of words and replacing it with the null character...


// if condition initialized..
        if (strcmp(words, "q") != 0)
        {

            nextWord = strtok(words, " ");
            // reading the string as series of tokens and storing into the nextWord variable..
            wordsCounter = 1;
            // assinging one value to variable wordsCounter..

            // nested while intialized inside do-while..
            while (nextWord)
            {
                // printing the wordsCounter and nextWord with the help of print function...
                printf("Word #%d is \'%s\'\n", wordsCounter++, nextWord);

                // reading the string as series of tokens and storing into the nextWord variable..
                nextWord = strtok(NULL, " ");
            }
        }


    } while (strcmp(words, "q") != 0);

    // last statement of our program and then it ends....
    printf("*** End of Tokenizing Words Demo ***\n\n");



    /* Version 2 */

    //replaced the old variables and introduced new variables for better functionality...

                // printing the start of our program...
    printf("* start of tokenizing phrases demo **\n");


    // declearing an array named phrases with the buffer_size, a pointer with the named nextphrase assigning null value to it...
    char phrases[BUFFER_SIZE];
    char* nextphrase = NULL;

    // declearing phrasescounter interger datatype variable..
    int phrasescounter;

    //do-while initialized...
    do
    {
        //print the below statement with the help of print function...
        printf("type a few phrases separated by comma(q - to quit):\n");

        //taking the user input and storing it in phrases variable already defined..
        fgets(phrases, BUFFER_SIZE, stdin);


        // cutting of the last character of phrases and replacing it with the null character...
        phrases[strlen(phrases) - 1] = '\0';


        //if condition intialized...
        if ((strcmp(phrases, "q") != 0))
        {

            // reading the string as series of tokens and storing into the nextword variable..
            nextphrase = strtok(phrases, ",");

            // assinging one value to variable phrasecounter..
            phrasescounter = 1;

            //nested while in do-while loop
            while (nextphrase)
            {
                // printing the phrasecounter and nextphrase with the help of print function...
                printf("phrase #%d is \'%s\'\n", phrasescounter++, nextphrase);

                // reading the string as series of tokens and storing into the nextword variable..
                nextphrase = strtok(NULL, ",");
            }
        }

    } while (strcmp(phrases, "q") != 0);

    // last statement of our program and then it ends....
    printf("* end of tokenizing phrases demo *\n\n");

    /* Version 3 */



    //showing starting message...
    printf("*** Start of Searching Strings Demo ***\n");
    // declaring two char arrays called hay stack and needle with BUFFER_SIZE ...
    char haystack[BUFFER_SIZE];
    char needle[BUFFER_SIZE];
    //declaring a pointer called occurrence and initializing it to a safe NULL ... 
    char* occurrence = NULL;

    do {
        //asking user to input a string...
        printf("Type the string (q - to quit):\n");

        //reading the string of the size of BUFFER_SIZE and save it in haystack array...
        fgets(haystack, BUFFER_SIZE, stdin);

        //adding the null termitator..
        haystack[strlen(haystack) - 1] = '\0';

        //cheacking if user wants to quit buy comparing "q" to user input saved in haystack... 
        if (strcmp(haystack, "q") != 0) {

            //asking user to for another string...
            printf("Type the substring:\n");

            //reading the string of the size of BUFFER_SIZE and save it in needle array...
            fgets(needle, BUFFER_SIZE, stdin);

            //adding the null termitator..
            needle[strlen(needle) - 1] = '\0';

            //cheacking if the sub_string needle is included in main_string haystack...
            occurrence = strstr(haystack, needle);

            //cheack if occurrence is not zero fo it means it found needle in haystack...
            if (occurrence)

                //showing what position was the needle found...
                printf("\'%s\' found at %d position\n", needle,
                    (int)(occurrence - haystack));

            //showing message "Not found" if needle was not in haystack...
            else
                printf("Not found\n");
        }


    //we should keep doimg all this till user puts "q"...
    } while (strcmp(haystack, "q") != 0);

    //end of program message...
    printf("*** End of Searching Strings Demo ***\n\n");


}
