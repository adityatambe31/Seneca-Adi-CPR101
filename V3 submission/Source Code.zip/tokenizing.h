// TOKENIZING MODULE HEADER 
#ifndef _TOKENIZING_H_ // checking if  identifier "_TOKENIZING_H_" is not defined

#define _TOKENIZING_H_ // defining identifier "_TOKENIZING_H_" is not defined
#include <stdio.h> // include the standard library for input output operations.
#include <string.h> // including the string library


void tokenizing(void); // declearation of the function for "tokenizing" function with zero parameters.

#endif 