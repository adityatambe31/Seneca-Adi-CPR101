// FUNDAMENTALS MODULE SOURCE
#define _CRT_SECURE_NO_WARNINGS
#define BUFFER_SIZE 80
#define NUM_INPUT_SIZE 10
#include "fundamentals.h"


// starting "fundamentals" function with void as an argument passed to the function..
void fundamentals(void) 
{
    /* Version 1 */

            // printing the statement to start of our program...
            printf("*** Start of Indexing Strings Demo***\n");
        
        // declearing the character arrays named buffer1 and numInput with sizes BUFFER_SIZE and NUM_INPUT_SIZE respectively.
        char buffer1[BUFFER_SIZE];
        char numInput[NUM_INPUT_SIZE];
        size_t position;
    
    do 
    {
            // printing the statement with the printf function...
            printf("Type not empty string (q - to quit):\n");
        
        
        // taking the above user input and storing it in buffer1...
        fgets(buffer1, BUFFER_SIZE, stdin);

        // cutting of the last character of buffer1 and replacing it with the null character...
        buffer1[strlen(buffer1) - 1] = '\0';
        
        // if condition initalized...
        if (strcmp(buffer1, "q") != 0) 
        {
                // printing the statement with the print function
                printf("Type the character position within the string:\n");


                // taking the above user input and storing it in numInput...
                fgets(numInput, NUM_INPUT_SIZE, stdin);
                
                // cutting of the last character of numInput and replacing it with the null character...
                numInput[strlen(numInput) - 1] = '\0';

                /* converting string of characters and then representing it as an actual integers
                and then storing it into position*/
                position = atoi(numInput);

                    // if condtion intialized, and will enter this sequence, if position would be greater then strlen(buffer1), else it won't...
                    if (position >= strlen(buffer1)) 
                    {
                        /* converting string of characters and then representing it as an actual integers
                        and then storing it into position*/
                        position = strlen(buffer1) - 1;
                        
                        // printing the statement with print function...
                        printf("Too big... Position reduced to max. available\n");
                    }

                // printing the character buffer1, (int)postion with the help of printf funtion
                printf("The character found at %d position is \'%c\'\n",
                (int)position, buffer1[position]);
        }

    } while (strcmp(buffer1, "q") != 0);

                // last print statement for end of our program..
                printf("*** End of Indexing Strings Demo ***\n\n");




// /* Version 2 */

    /*removing the numInput and size_t position variables and its uses and replacing all three variables with one variable 
    called buffer2 and using it in the entire code for better stability in the code */
    
                // printing the statement to start of our program...
               printf("* Start of Measuring String Demo *\n");
               
       // declearing the character arrays named buffer2 with size BUFFER_SIZE.
       char buffer2[BUFFER_SIZE];
       

       // do-while loop initialized...
       do 
       {
               //printing the statement to take a string by using the print function..
               printf("Type a string (q - to quit):\n");
               
               // taking the user input of string and storing it in buffer2 by fget function..
               fgets(buffer2, BUFFER_SIZE, stdin);
       
       // cutting of the last character of buffer1 and replacing it with the null character...
       buffer2[strlen(buffer2) - 1] = '\0';
       
               //if condition initialized ...
               if (strcmp(buffer2, "q") != 0)

                   // if the condition above satisfies then, it prints the below print statement with the help of print function..
                   printf("The length of \'%s\' is %d characters\n",
                   buffer2, (int)strlen(buffer2));
           
       }   while (strcmp(buffer2, "q") != 0);
       

    // last print statement for end of our program..
    printf("* End of Measuring Strings Demo *\n\n");


/* Version 3 */
    //banner printing v3
  printf("*** Start of Copying Strings Demo ***\n");
    //defining the variables required for the string copying demo
    char destination[BUFFER_SIZE];
    char source[BUFFER_SIZE];

    do {
        //defining the destination string to a sane value
        destination[0] = '\0';
        printf("Destination string is reset to empty\n");
        //input request for the source string
        printf("Type the source string (q - to quit):\n");
        //saving the input
        fgets(source, BUFFER_SIZE, stdin);
        //confirm there is an end of string in the last position
        source[strlen(source) - 1] = '\0';
        //skip the copy if exit condition
        if (strcmp(source, "q") != 0) {
            //copying procedure
            strcpy(destination, source);
            //printing on a successfull copy
            printf("New destination string is \'%s\'\n", destination);
        }
        //exit condition of the loop
    } while (strcmp(source, "q") != 0);
    //exit message
    printf("*** End of Copying Strings Demo ***\n\n");

}
